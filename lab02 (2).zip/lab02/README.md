# lab02
Laboratorio de programación web sobre el Mundial 2026, que reúne cinco apartados. Desarrollado con HTML, CSS y JavaScript, utilizando una API, almacenamiento local y manejo de errores.   A web development project based on the 2026 World Cup, five interactive sections built with HTML, CSS, JavaScript, API integration,local storage and error handling
