"use strict";

/* CONFIGURACION */
const BASE = "https://worldcup26.ir";
const FAVORITE_KEY = "equipoFavorito";
const FAN_CACHE_KEY = "dashboardFanCache";
const ESPERAS_MS = [1000, 2000, 4000, 8000];
const STATUS_REINTENTABLES = [429, 500, 502, 503, 504];
const API_CACHE_PREFIX = "worldcup26ApiCache:";


/* ESTADO DE LA APLICACION */
const state = {
  teams: [],
  stadiums: [],
  groups: [],
  games: [],
  gamesAvailable: false,
  activeStadiumId: null,
  agendaFechas: [],
  agendaIndex: 0,
  agendaCache: {},
  timelinePartidos: [],
  timelineIndex: 0,
  timelineObserver: null,
  timelineIntentos: 0,
  matrixReady: false,
  endpointsDesdeCache: new Set()
};


/* ELEMENTOS DEL HTML */
const stadiumsList = document.getElementById("stadiumsList");
const stadiumGamesSection = document.getElementById("stadiumGamesSection");
const stadiumGamesList = document.getElementById("stadiumGamesList");
const selectedStadiumTitle = document.getElementById("selectedStadiumTitle");

const agendaFecha = document.getElementById("agendaFecha");
const agendaPrev = document.getElementById("agendaPrev");
const agendaNext = document.getElementById("agendaNext");
const agendaGrid = document.getElementById("agendaGrid");

const timelineList = document.getElementById("timelineList");
const timelineSentinel = document.getElementById("timelineSentinel");

const favoriteSelect = document.getElementById("favoriteSelect");
const fanWarning = document.getElementById("fanWarning");
const fanSummary = document.getElementById("fanSummary");
const fanMatches = document.getElementById("fanMatches");

const matrixContainer = document.getElementById("matrixContainer");
const matrixWarning = document.getElementById("matrixWarning");
const matrixRetry = document.getElementById("matrixRetry");

const featureHint = document.getElementById("featureHint");
const featureButtons = document.querySelectorAll("[data-section]");
const appSections = document.querySelectorAll(".app-section");
const alertBanner = document.getElementById("alertBanner");
const alertMsg = document.getElementById("alertMsg");


/* FUNCIONES ASINCRONAS */
async function esperar(ms, notificarSegundo) {
  let restantes = Math.ceil(ms / 1000);

  while (restantes > 0) {
    notificarSegundo?.(restantes);
    await new Promise(resolve => setTimeout(resolve, 1000));
    restantes -= 1;
  }
}

function mostrarAvisoApi(mensaje) {
  alertMsg.textContent = mensaje;
  alertBanner.classList.add("visible");
}

function ocultarAvisoApi() {
  alertBanner.classList.remove("visible");
}

function getNombreEndpoint(endpoint) {
  return endpoint.replace("/get/", "");
}

function actualizarAvisoCache() {
  if (state.endpointsDesdeCache.size === 0) {
    ocultarAvisoApi();
    return;
  }

  const endpoints = Array.from(state.endpointsDesdeCache)
    .map(getNombreEndpoint)
    .join(", ");

  mostrarAvisoApi(
    `Datos no actualizados: ${endpoints}. Se muestra copia local guardada.`
  );
}

function marcarDatosActualizados(endpoint) {
  state.endpointsDesdeCache.delete(endpoint);
  actualizarAvisoCache();
}

function marcarDatosDesdeCache(endpoint) {
  state.endpointsDesdeCache.add(endpoint);
  actualizarAvisoCache();
}

function guardarCache(endpoint, data) {
  localStorage.setItem(
    API_CACHE_PREFIX + endpoint,
    JSON.stringify({
      data: data,
      timestamp: Date.now()
    })
  );
}

function leerCache(endpoint) {
  const cache = localStorage.getItem(API_CACHE_PREFIX + endpoint);
  return cache ? JSON.parse(cache) : null;
}

function mostrarEsperaApi(datos) {
  if (datos.status === 429) {
    mostrarAvisoApi(
      `Limite de peticiones alcanzado (429). Reintentando en ${datos.segundosRestantes}s...`
    );
    return;
  }

  const estado = datos.status ?? "sin conexion";
  mostrarAvisoApi(
    `Error de API (${estado}). Reintentando en ${datos.segundosRestantes}s...`
  );
}

async function obtenerDatos(endpoint, { onEspera } = {}) {
  const totalIntentos = ESPERAS_MS.length + 1;
  let ultimoError = null;

  for (let intento = 1; intento <= totalIntentos; intento++) {
    try {
      const respuesta = await fetch(BASE + endpoint);

      if (!respuesta.ok) {
        const error = new Error(`HTTP ${respuesta.status} en ${endpoint}`);
        error.status = respuesta.status;
        throw error;
      }

      const data = await respuesta.json();
      guardarCache(endpoint, data);
      marcarDatosActualizados(endpoint);
      return {
        data: data,
        desdeCache: false,
        timestamp: Date.now()
      };
    } catch (err) {
      ultimoError = err;

      const status = typeof err.status === "number" ? err.status : null;
      const reintentable =
        status === null || STATUS_REINTENTABLES.includes(status);

      console.warn(
        `[api] ${endpoint} - intento ${intento}/${totalIntentos} fallo ` +
        `(${status ?? "sin conexion"})`
      );

      if (!reintentable || intento === totalIntentos) break;

      const esperaMs = ESPERAS_MS[intento - 1];
      await esperar(esperaMs, segundosRestantes =>
        onEspera?.({
          endpoint: endpoint,
          status: status,
          intento: intento,
          totalIntentos: totalIntentos,
          segundosRestantes: segundosRestantes
        })
      );
    }
  }

  const cacheado = leerCache(endpoint);

  if (cacheado) {
    marcarDatosDesdeCache(endpoint);
    console.warn(
      `[api] ${endpoint} - mostrando copia local del ` +
      `${new Date(cacheado.timestamp).toLocaleString()}`
    );
    return {
      data: cacheado.data,
      desdeCache: true,
      timestamp: cacheado.timestamp
    };
  }

  throw ultimoError;
}


/* LLAMADAS A LA API */
async function loadTeams() {
  try {
    const resultado = await obtenerDatos("/get/teams", {
      onEspera: mostrarEsperaApi
    });
    const data = resultado.data;
    state.teams = data.teams || [];
    return true;
  } catch (error) {
    console.error("Error al cargar equipos:", error);
    state.teams = [];
    return false;
  }
}

async function loadStadiums() {
  try {
    const resultado = await obtenerDatos("/get/stadiums", {
      onEspera: mostrarEsperaApi
    });
    const data = resultado.data;
    state.stadiums = data.stadiums || [];
    populateStadiums();
  } catch (error) {
    console.error("Error al cargar sedes:", error);
    stadiumsList.textContent = "No se pudieron cargar las sedes.";
  }
}

async function loadGroups() {
  try {
    const resultado = await obtenerDatos("/get/groups", {
      onEspera: mostrarEsperaApi
    });
    const data = resultado.data;
    state.groups = data.groups || [];
    return true;
  } catch (error) {
    console.error("Error al cargar grupos:", error);
    state.groups = [];
    return false;
  }
}

async function loadGames() {
  try {
    const resultado = await obtenerDatos("/get/games", {
      onEspera: mostrarEsperaApi
    });
    const data = resultado.data;
    state.games = data.games || [];
    state.gamesAvailable = true;
    return true;
  } catch (error) {
    console.error("Error al cargar partidos:", error);
    state.games = [];
    state.gamesAvailable = false;
    return false;
  }
}


/* FUNCIONES GENERALES */
function getTeamName(teamId) {
  const team = state.teams.find(item => item.id == teamId);

  if (team) {
    return team.name_en;
  } else {
    return `Equipo ${teamId}`;
  }
}

function getDia(localDate) {
  return String(localDate).split(" ")[0];
}

function ordenarFecha(fecha) {

  let partes = fecha.split("/");

  let mes = Number(partes[0]);
  let dia = Number(partes[1]);
  let año = Number(partes[2]);

  let fechaReal = new Date(
    año,
    mes - 1,
    dia
  );

  return fechaReal.getTime();
}

function getFechaCompleta(localDate) {

  let texto = String(localDate);

  let partes = texto.split(" ");

  let fechaTexto = partes[0];

  let horaTexto = partes[1];


  let fecha = fechaTexto.split("/");

  let mes = Number(fecha[0]);
  let dia = Number(fecha[1]);
  let año = Number(fecha[2]);


  let hora = "00";
  let minutos = "00";


  if (horaTexto) {

    let partesHora = horaTexto.split(":");

    hora = Number(partesHora[0]);
    minutos = Number(partesHora[1]);

  }


  let fechaCompleta = new Date(
    año,
    mes - 1,
    dia,
    hora,
    minutos
  );


  return fechaCompleta.getTime();
}

/* 2.1 TOUR VIRTUAL DE SEDES */
function populateStadiums() {
  stadiumsList.innerHTML = "";

  state.stadiums.forEach(stadium => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "stadium-button";
    button.dataset.stadiumId = stadium.id;
    button.textContent = stadium.name_en || `Sede ${stadium.id}`;
    stadiumsList.appendChild(button);
  });
}

function showGamesByStadium(stadiumId) {
  if (!state.gamesAvailable) {
    stadiumGamesList.innerHTML = `
      <p class="games-error">
        No se pudieron cargar los partidos de esta sede.
      </p>
    `;
    return;
  }

  const filteredGames = state.games.filter(game =>
    String(game.stadium_id) === String(stadiumId)
  );

  if (filteredGames.length === 0) {
    stadiumGamesList.innerHTML = "<p>No hay partidos registrados en esta sede.</p>";
    return;
  }

  let html = "";

  filteredGames.forEach(game => {
    html += `
      <div class="game-card">
        <strong>
          ${game.home_team_name_en || "Por definir"}
          vs.
          ${game.away_team_name_en || "Por definir"}
        </strong>
        <p>${game.local_date || "Fecha pendiente"}</p>
      </div>
    `;
  });

  stadiumGamesList.innerHTML = html;
}

stadiumsList.addEventListener("click", event => {
  const button = event.target.closest(".stadium-button");
  if (!button) return;

  state.activeStadiumId = button.dataset.stadiumId;

  const activeButton = document.querySelector(".stadium-button.active");
  if (activeButton) activeButton.classList.remove("active");

  button.classList.add("active");

  const stadium = state.stadiums.find(item =>
    String(item.id) === String(state.activeStadiumId)
  );

  selectedStadiumTitle.textContent = `Partidos de ${stadium.name_en}`;
  showGamesByStadium(state.activeStadiumId);

  stadiumGamesSection.scrollIntoView({
    behavior: "smooth",
    block: "start"
  });
});


/* 2.2 AGENDA SIMULTANEA */
function prepararAgenda() {
  const grupos = {};

  state.games.forEach(game => {
    const dia = getDia(game.local_date);

    if (!grupos[dia]) grupos[dia] = [];
    grupos[dia].push(game);
  });

  state.agendaFechas = Object.keys(grupos)
    .filter(dia => grupos[dia].length >= 2)
    .sort((a, b) => ordenarFecha(a) - ordenarFecha(b));

  state.agendaCache = {};
  state.agendaIndex = 0;
  mostrarAgenda();
}

function mostrarAgendaSkeleton() {
  agendaGrid.innerHTML = `
    <div class="agenda-skeleton"></div>
    <div class="agenda-skeleton"></div>
  `;
}

function mostrarAgenda() {
  const fecha = state.agendaFechas[state.agendaIndex];

  if (!fecha) {
    agendaFecha.textContent = "Cargando agenda...";
    agendaPrev.disabled = true;
    agendaNext.disabled = true;
    mostrarAgendaSkeleton();
    return;
  }

  if (!state.agendaCache[fecha] && state.gamesAvailable) {
    state.agendaCache[fecha] = state.games.filter(game =>
      getDia(game.local_date) === fecha
    );
    
  }

  const partidos = state.agendaCache[fecha];

  if (!partidos) {
    agendaFecha.textContent = fecha;
    mostrarAgendaSkeleton();
    return;
  }

  agendaFecha.textContent = fecha;
  agendaPrev.disabled = state.agendaIndex === 0;
  agendaNext.disabled = state.agendaIndex === state.agendaFechas.length - 1;

  let html = "";

  partidos.forEach(game => {
    html += `
      <article class="agenda-card">
        <strong>
          ${getTeamName(game.home_team_id)}
          vs.
          ${getTeamName(game.away_team_id)}
        </strong>
        <p>${game.local_date}</p>
      </article>
    `;
  });

  agendaGrid.innerHTML = html;
}

async function cambiarFechaAgenda(move) {
  const nuevaPosicion = state.agendaIndex + move;

  if (nuevaPosicion < 0 || nuevaPosicion >= state.agendaFechas.length) {
    return;
  }

  state.agendaIndex = nuevaPosicion;

  if (!state.agendaCache[state.agendaFechas[state.agendaIndex]] &&
      !state.gamesAvailable) {
    mostrarAgendaSkeleton();
    await loadGames();
    prepararAgenda();
    return;
  }

  mostrarAgenda();
}

agendaPrev.addEventListener("click", () => {
  cambiarFechaAgenda(-1);
});

agendaNext.addEventListener("click", () => {
  cambiarFechaAgenda(1);
});


/* 2.3 TIMELINE INFINITO */
function iniciarTimeline() {
  if (!state.gamesAvailable) {
    mostrarTimelineError();
    return;
  }

  if (state.timelineObserver) {
    state.timelineObserver.disconnect();
  }

  state.timelinePartidos = [...state.games].sort((a, b) =>
    getFechaCompleta(a.local_date) - getFechaCompleta(b.local_date)
  );

  state.timelineIndex = 0;
  state.timelineIntentos = 0;
  timelineList.innerHTML = "";
  timelineSentinel.textContent = "";

  cargarMasTimeline();

  state.timelineObserver = new IntersectionObserver(entries => {
    if (entries[0].isIntersecting) {
      cargarMasTimeline();
    }
  });

  state.timelineObserver.observe(timelineSentinel);
}

function cargarMasTimeline() {
  const bloque = state.timelinePartidos.slice(
    state.timelineIndex,
    state.timelineIndex + 10
  );

  let html = "";

  bloque.forEach(game => {
    html += `
      <article class="timeline-card">
        <strong>
          ${game.home_team_name_en || "Por definir"}
          vs.
          ${game.away_team_name_en || "Por definir"}
        </strong>
        <p>${game.local_date}</p>
      </article>
    `;
  });

  timelineList.insertAdjacentHTML("beforeend", html);
  state.timelineIndex += bloque.length;

  if (state.timelineIndex >= state.timelinePartidos.length &&
      state.timelineObserver) {
    state.timelineObserver.disconnect();
    timelineSentinel.textContent = "Fin del timeline";
  }
}

function mostrarTimelineError() {
  if (state.timelineObserver) {
    state.timelineObserver.disconnect();
  }

  timelineList.innerHTML = `
    <div class="timeline-error">
      <p>No se pudieron cargar los partidos.</p>
      <button type="button" id="timelineRetry">Reintentar</button>
    </div>
  `;
  timelineSentinel.textContent = "";
}

async function reintentarTimeline() {
  state.timelineIntentos++;

  const espera = Math.min(
    2000 * 2 ** (state.timelineIntentos - 1),
    10000
  );

  timelineList.innerHTML = `
    <div class="timeline-skeleton"></div>
    <div class="timeline-skeleton"></div>
  `;

  await esperar(espera);

  const exito = await loadGames();

  if (exito) {
    prepararAgenda();
    iniciarTimeline();
    if (state.matrixReady) actualizarCeldasMatriz();
  } else {
    mostrarTimelineError();
  }
}

timelineList.addEventListener("click", event => {
  if (event.target.id === "timelineRetry") {
    reintentarTimeline();
  }
});


/* 2.4 DASHBOARD DEL FANATICO INCONDICIONAL */
function getFanColor(teamId) {
  return `hsl(${Number(teamId) * 47 % 360}, 75%, 55%)`;
}

function llenarSelectorFavorito() {
  favoriteSelect.innerHTML = `<option value="">Seleccione un equipo</option>`;

  state.teams.forEach(team => {
    const option = document.createElement("option");
    option.value = team.id;
    option.textContent = team.name_en;
    favoriteSelect.appendChild(option);
  });

  favoriteSelect.value = localStorage.getItem(FAVORITE_KEY) || "";
}

function buscarGrupo(teamId) {
  let datos = null;

  state.groups.forEach(group => {
    group.teams.forEach((team, index) => {
      if (team.team_id == teamId) {
        datos = {
          grupo: group.name,
          posicion: index + 1,
          pts: team.pts,
          gf: team.gf,
          ga: team.ga
        };
      }
    });
  });

  return datos;
}

function mostrarFanCache() {
  const cache = JSON.parse(localStorage.getItem(FAN_CACHE_KEY) || "null");
  if (!cache) return;

  document.documentElement.style.setProperty("--fan-accent", cache.color);
  fanWarning.textContent = "Datos no actualizados";
  fanSummary.innerHTML = cache.summary;
  fanMatches.innerHTML = cache.matches;
}

function mostrarDashboardFan(teamId) {
  if (!teamId) return;

  const team = state.teams.find(item => item.id == teamId);
  const grupo = buscarGrupo(teamId);
  const partidos = state.games.filter(game =>
    game.home_team_id == teamId || game.away_team_id == teamId
  );

  if (!team || !grupo || partidos.length === 0) {
    mostrarFanCache();
    return;
  }

  const color = getFanColor(teamId);
  document.documentElement.style.setProperty("--fan-accent", color);
  fanWarning.textContent = "";

  fanSummary.innerHTML = `
    <div>
      <img src="${team.flag}" alt="">
      <strong>${team.name_en}</strong>
    </div>
    <p>Grupo ${grupo.grupo} - Posición ${grupo.posicion}</p>
    <p>PTS: ${grupo.pts} - GF: ${grupo.gf} - GA: ${grupo.ga}</p>
  `;

  let html = "";

  partidos.forEach(game => {
    html += `
      <article class="fan-match">
        <strong>
          ${getTeamName(game.home_team_id)}
          vs.
          ${getTeamName(game.away_team_id)}
        </strong>
        <p>${game.local_date}</p>
      </article>
    `;
  });

  fanMatches.innerHTML = html;

  localStorage.setItem(FAN_CACHE_KEY, JSON.stringify({
    color: color,
    summary: fanSummary.innerHTML,
    matches: fanMatches.innerHTML
  }));
}

function iniciarDashboardFan() {
  const favorito = localStorage.getItem(FAVORITE_KEY);

  if (state.teams.length > 0) {
    llenarSelectorFavorito();
  }

  if (favorito) {
    favoriteSelect.value = favorito;
    mostrarDashboardFan(favorito);
  } else {
    mostrarFanCache();
  }
}

favoriteSelect.addEventListener("change", () => {
  if (!favoriteSelect.value) {
    localStorage.removeItem(FAVORITE_KEY);
    fanWarning.textContent = "";
    fanSummary.textContent = "Seleccione un equipo para ver su dashboard.";
    fanMatches.innerHTML = "";
    return;
  }

  localStorage.setItem(FAVORITE_KEY, favoriteSelect.value);
  mostrarDashboardFan(favoriteSelect.value);
});


/* 2.5 MATRIZ DE ENFRENTAMIENTOS POR GRUPO */
function buscarPartidoEntre(teamA, teamB) {
  return state.games.find(game =>
    (game.home_team_id == teamA && game.away_team_id == teamB) ||
    (game.home_team_id == teamB && game.away_team_id == teamA)
  );
}

function getResultadoMatriz(rowId, colId) {
  if (!state.gamesAvailable) {
    return "Pendiente";
  }

  const game = buscarPartidoEntre(rowId, colId);
  const jugado = game && String(game.finished).toLowerCase() === "true";

  if (!jugado) {
    return "Pendiente";
  }

  if (game.home_team_id == rowId) {
    return `${game.home_score} - ${game.away_score}`;
  }

  return `${game.away_score} - ${game.home_score}`;
}

function crearMatrizGrupos() {
  if (state.groups.length === 0 || state.teams.length === 0) {
    matrixContainer.textContent = "No se pudieron cargar los grupos.";
    return;
  }

  let html = "";

  state.groups.forEach(group => {
    html += `
      <article class="matrix-group">
        <h3>Grupo ${group.name}</h3>
        <table>
          <thead>
            <tr>
              <th></th>
    `;

    group.teams.forEach(team => {
      html += `<th>${getTeamName(team.team_id)}</th>`;
    });

    html += `
            </tr>
          </thead>
          <tbody>
    `;

    group.teams.forEach(rowTeam => {
      html += `
        <tr>
          <th>${getTeamName(rowTeam.team_id)}</th>
      `;

      group.teams.forEach(colTeam => {
        if (rowTeam.team_id == colTeam.team_id) {
          html += `<td class="matrix-disabled">---</td>`;
        } else {
          html += `
            <td data-row="${rowTeam.team_id}" data-col="${colTeam.team_id}">
              ${getResultadoMatriz(rowTeam.team_id, colTeam.team_id)}
            </td>
          `;
        }
      });

      html += "</tr>";
    });

    html += `
          </tbody>
        </table>
      </article>
    `;
  });

  matrixContainer.innerHTML = html;
  state.matrixReady = true;
  actualizarAvisoMatriz();
}

function actualizarCeldasMatriz() {
  document.querySelectorAll("[data-row][data-col]").forEach(cell => {
    cell.textContent = getResultadoMatriz(
      cell.dataset.row,
      cell.dataset.col
    );
  });

  actualizarAvisoMatriz();
}

function actualizarAvisoMatriz() {
  if (state.gamesAvailable) {
    matrixWarning.textContent = "";
    matrixRetry.style.display = "none";
  } else {
    matrixWarning.textContent =
      "Partidos no disponibles: todas las celdas quedan pendientes.";
    matrixRetry.style.display = "inline-block";
  }
}

async function reintentarPartidosMatriz() {
  matrixWarning.textContent = "Reintentando partidos...";

  const exito = await loadGames();

  if (exito) {
    actualizarCeldasMatriz();
    prepararAgenda();
    iniciarTimeline();
  } else {
    actualizarAvisoMatriz();
  }
}

matrixRetry.addEventListener("click", () => {
  reintentarPartidosMatriz();
});


/* MENU DE APARTADOS */
function mostrarApartado(sectionId) {
  appSections.forEach(section => {
    section.classList.toggle("active", section.id === sectionId);
  });

  featureButtons.forEach(button => {
    button.classList.toggle("active", button.dataset.section === sectionId);
  });

  featureHint.textContent = "";

  if (sectionId === "timelineView" && state.timelineObserver) {
    state.timelineObserver.disconnect();
    state.timelineObserver.observe(timelineSentinel);
  }
}

featureButtons.forEach(button => {
  button.addEventListener("click", () => {
    mostrarApartado(button.dataset.section);
  });
});


/* INICIO */
async function init() {
  await loadTeams();
  await loadGames();
  await loadGroups();
  await loadStadiums();

  iniciarDashboardFan();
  prepararAgenda();
  iniciarTimeline();
  crearMatrizGrupos();
}

init();
